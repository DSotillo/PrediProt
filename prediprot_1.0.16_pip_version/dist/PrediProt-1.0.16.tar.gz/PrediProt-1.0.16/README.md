Protein complex structure predictor. From a set of PDB chain pairs,
PrediProt builds complete PDB models according to various parameters.
For more info, consult https://github.com/alexpgar/sbi-pyt-project.
